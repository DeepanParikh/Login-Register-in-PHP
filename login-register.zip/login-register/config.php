<?php
$conn=mysql_connect("localhost","root","");
if(!$conn){
    echo "database not connected";
}
mysql_select_db("rl",$conn);
?>


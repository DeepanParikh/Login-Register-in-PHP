<?php
include 'config.php';
if(isset($_REQUEST['submit'])){
$name=$_REQUEST['name'];
$email=$_REQUEST['email'];
$username=$_REQUEST['username'];
$password=$_REQUEST['password'];
$repassword=$_REQUEST['repassword'];
$birthmonth=$_REQUEST['birthmonth'];
$birthday=$_REQUEST['birthday'];
$birthyear=$_REQUEST['birthyear'];
$gender=$_REQUEST['gender'];
$phone=$_REQUEST['phone'];


  $x=time();
	  $a=$x.implode(",".$x,$_FILES['url']['name']);
	  foreach($_FILES['url']['tmp_name'] as $key=> $tmp_name)
		{
			$file_name= $_FILES['url']['name'][$key];
			$file_tmp= $_FILES['url']['tmp_name'][$key];
			move_uploaded_file($file_tmp,"ImageUpload/".$x.$file_name);
		}
$q="INSERT INTO user VALUES ('0','$name','$email','$username','$password','$repassword','$birthmonth','$birthday','$birthyear','$gender','$phone','$a')";
	  mysql_query($q);
	  
	  
	  
	  header("location:index.php");
	}
	
?>




<!DOCTYPE html>
<html>
<head>
<title>Registration Form</title>
	<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7; IE=EmulateIE9">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
    <link rel="stylesheet" type="text/css" href="style.css" media="all" />
    <link rel="stylesheet" type="text/css" href="demo.css" media="all" />
</head>
<body>
<div class="container">
			<!-- freshdesignweb top bar -->
            <div class="freshdesignweb-top">
                
               
                <div class="clr"></div>
            </div><!--/ freshdesignweb top bar -->
			<header>
				
            </header>       
      <div  class="form">
    		<form id="contactform" method="post" enctype="multipart/form-data"> 
    			<p class="contact"><label for="name">Name</label></p> 
    			<input id="name" name="name" placeholder="First and last name" required="" tabindex="1" type="text"> 
    			 
    			<p class="contact"><label for="email">Email</label></p> 
    			<input id="email" name="email" placeholder="example@domain.com" required="" type="email"> 
                
                <p class="contact"><label for="username">Create a username</label></p> 
    			<input id="username" name="username" placeholder="username" required="" tabindex="2" type="text"> 
    			 
                <p class="contact"><label for="password">Create a password</label></p> 
    			<input type="password" id="password" name="password" required=""> 
                <p class="contact"><label for="repassword">Confirm your password</label></p> 
    			<input type="password" id="repassword" name="repassword" required=""> 
        
               <fieldset>
                 <label>Birthday</label>
                  <label class="month"> 
                  <select class="select-style" name="birthmonth">
                  <option value="">Month</option>
                  <option  value="01">January</option>
                  <option value="02">February</option>
                  <option value="03" >March</option>
                  <option value="04">April</option>
                  <option value="05">May</option>
                  <option value="06">June</option>
                  <option value="07">July</option>
                  <option value="08">August</option>
                  <option value="09">September</option>
                  <option value="10">October</option>
                  <option value="11">November</option>
                  <option value="12" >December</option>
                  </label>
                 </select>    
                <label>Day<input class="birthday" maxlength="2" name="birthday"  placeholder="Day" required=""></label>
                <label>Year <input class="birthyear" maxlength="4" name="birthyear" placeholder="Year" required=""></label>
              </fieldset>
  
            <select class="select-style gender" name="gender">
            <option value="select">i am..</option>
            <option value="m">Male</option>
            <option value="f">Female</option>
            
            </select><br><br>
            
            <p class="contact"><label for="phone">Mobile phone</label></p> 
			
            <input id="phone" name="phone" placeholder="phone number" required="" type="text"> <br>
			<br>
			<p>Upload your Image</p><br>
			<input type="file" name="url[]"/><br /><br />
			
			
            <input class="buttom" name="submit" id="submit" tabindex="5" value="Sign me up!" type="submit"> 	 
   </form> 
</div>      
</div>

</body>
</html>

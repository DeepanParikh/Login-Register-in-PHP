<?php
session_start();
	$con=mysql_connect('localhost','root','');
	if(!$con)
	{
		echo "Not Connect database.......";
	}
	mysql_select_db("rl",$con);
	if(isset($_REQUEST['login']))
	{
		if($_REQUEST['username']=="" && $_REQUEST['password']=="")
		{
			echo "username and password.....";
		}
		else
		{
			$e=mysql_query("select * from user where username='$_REQUEST[username]' and password='$_REQUEST[password]'");
			while($r=mysql_fetch_array($e))
			{
			$_SESSION['login']=$r['name'];
				header("location:welcome.php");
			}
			echo "Enter valid email id and password...!";
		}
	}
?>

















<!DOCTYPE html>
<html>
<head>
<title>Registration Form</title>
	<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7; IE=EmulateIE9">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
    <link rel="stylesheet" type="text/css" href="style.css" media="all" />
    <link rel="stylesheet" type="text/css" href="demo.css" media="all" />
</head>
<body>
<div class="container">
			<!-- freshdesignweb top bar -->
            <div class="freshdesignweb-top">
                
               
                <div class="clr"></div>
            </div><!--/ freshdesignweb top bar -->
			<header>
				
            </header>       
      <div  class="form">
    		<form id="contactform"> 
    			
                
                <p class="contact"><label for="username">Username</label></p> 
    			<input id="username" name="username" placeholder="username" required="" tabindex="2" type="text"> 
    			 
                <p class="contact"><label for="password"> Password</label></p> 
    			<input type="password" id="password" name="password" required=""> 
                <p class="contact"><label for="repassword">Re-enter your password</label></p> 
    			<input type="password" id="repassword" name="repassword" required=""> 
        
              
            <input class="buttom" name="login" id="submit" tabindex="5" value="log me in!" type="submit"> 	 
   </form> 
</div>      
</div>

</body>
</html>

<?php
	error_reporting(0); 
	$con=mysql_connect('localhost','root','');
	if(!$con)
	{
  		echo "Database not found";
	}
	mysql_select_db("rl",$con);
	
	
	
		
		
		
		
?>


<?php
	$e=mysql_query("SELECT * FROM user");
	while($r=mysql_fetch_array($e))
	{
	$abc=explode(",",$r['path']);
		?>


<?php
		foreach($abc as $xxx)
					{
                ?>
				
				
				 <img height="50px" width="100px" src="ImageUpload/<?php echo $xxx;?>"  />
                <?php
					}					
                ?>          



<?php
}
?>        